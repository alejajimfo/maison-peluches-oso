// Lee un catálogo de Google Sites desde el servidor de Netlify (evita bloqueos CORS).
// Solo permite los tres catálogos de la tienda.
const PERMITIDOS = [
  "https://sites.google.com/view/catalogopeluchesoso",
  "https://sites.google.com/view/catalogoimportadosu/p%C3%A1gina-principal",
  "https://sites.google.com/view/catalogopeluches"
];

export default async (req) => {
  const u = new URL(req.url).searchParams.get("u") || "";
  if (!PERMITIDOS.includes(u)) return new Response("No permitido", { status: 400 });
  try {
    const r = await fetch(u, { headers: { "User-Agent": "Mozilla/5.0" } });
    const html = await r.text();
    return new Response(html, {
      status: r.status,
      headers: {
        "content-type": "text/html; charset=utf-8",
        "cache-control": "public, max-age=1800"
      }
    });
  } catch (e) {
    return new Response("Error", { status: 502 });
  }
};
